self.addEventListener("install", () => {
  self.skipWaiting();
});
